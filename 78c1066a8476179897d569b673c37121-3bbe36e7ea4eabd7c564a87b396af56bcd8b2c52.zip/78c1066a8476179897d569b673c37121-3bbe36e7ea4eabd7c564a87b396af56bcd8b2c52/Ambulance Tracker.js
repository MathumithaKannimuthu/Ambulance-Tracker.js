jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Login from './Login';
import Dashboard from './Dashboard';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Check user authentication
  }, []);

  return (
    <BrowserRouter>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/dashboard" component={Dashboard} />
      </Switch>
    </BrowserRouter>
  );
}

export default App;

Login.js

jsx
import React, { useState } from 'react';
import axios from 'axios';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/login', {
        username,
        password,
      });
      // Handle login success
    } catch (error) {
      // Handle login error
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Username"
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
      />
      <button type="submit">Login</button>
    </form>
  );
}

export default Login;


Dashboard.js

jsx
import React from 'react';
import AmbulanceList from './AmbulanceList';
import AmbulanceMap from './AmbulanceMap';
import RequestAmbulance from './RequestAmbulance';

function Dashboard() {
  return (
    <div>
      <h1>Ambulance Tracker Dashboard</h1>
      <AmbulanceList />
      <AmbulanceMap />
      <RequestAmbulance />
    </div>
  );
}

export default Dashboard;


AmbulanceList.js

jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AmbulanceList() {
  const [ambulances, setAmbulances] = useState([]);

  useEffect(() => {
    axios.get('/api/ambulances')
      .then((response) => {
        setAmbulances(response.data);
      })
      .catch((error) => {
        // Handle error
      });
  }, []);

  return (
    <ul>
      {ambulances.map((ambulance) => (
        <li key={(link unavailable)}>
          {ambulance.name} - {ambulance.location}
        </li>
      ))}
    </ul>
  );
}

export default AmbulanceList;


AmbulanceMap.js

jsx
import React from 'react';
import { GoogleMap, Marker } from 'react-google-maps';

function AmbulanceMap() {
  const [ambulances, setAmbulances] = useState([]);

  // Fetch ambulance locations from API

  return (
    <GoogleMap
      defaultZoom={12}
      defaultCenter={{ lat: 37.7749, lng: -122.4194 }}
    >
      {ambulances.map((ambulance) => (
        <Marker
          key={(link unavailable)}
          position={{ lat: ambulance.latitude, lng: ambulance.longitude }}
        />
      ))}
    </GoogleMap>
  );
}

export default AmbulanceMap;


RequestAmbulance.js

jsx
import React, { useState } from 'react';
import axios from 'axios';

function RequestAmbulance() {
  const [location, setLocation] = useState('');
  const [emergency, setEmergency] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/request-ambulance', {
        location,
        emergency,
      });
      // Handle request success
    } catch (error) {
      // Handle request error
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        placeholder="Location"
      />
      <input
        type="text"
        value={emergency}
        onChange={(e) => setEmergency(e.target.value)}
        placeholder="Emergency Details"
      />
      <button type="submit">Request Ambulance</button>
    </form
